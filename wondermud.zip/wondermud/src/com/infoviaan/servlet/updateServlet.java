package com.infoviaan.servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.infoviaan.bean.StudentBean;
import com.infoviaan.model.StudentDAO;

@WebServlet("/updateServlet")
public class updateServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		int roll = Integer.parseInt(request.getParameter("rollNo"));
		StudentBean std = new StudentDAO().getStudentRecord(roll);

		RequestDispatcher rd = request.getRequestDispatcher("updateStudent.jsp");
		request.setAttribute("STD", std);
		rd.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String name = request.getParameter("sname");
		int rollno = Integer.parseInt(request.getParameter("srollno"));
		String address = request.getParameter("saddress");
		String course = request.getParameter("scourse");
		String mobile = request.getParameter("smobile");

		StudentBean sb = new StudentBean(name, rollno, address, course, mobile);
		int x = new StudentDAO().updateStudent(sb);
		ArrayList<StudentBean> slist = new StudentDAO().getAllStudent();

		if (x != 0) {
			RequestDispatcher rd = request.getRequestDispatcher("studentDetails.jsp");
			request.setAttribute("STD", slist);
			request.setAttribute("msg", "Student Record updated Scuccessfully");
			rd.forward(request, response);
		}
	}

}
