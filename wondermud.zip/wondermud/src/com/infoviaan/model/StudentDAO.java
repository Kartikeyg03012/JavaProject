package com.infoviaan.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.infoviaan.bean.StudentBean;

public class StudentDAO {

	public Connection createConnection() {

		Connection con = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/management", "root", "root");
		} catch (Exception e) {

		}
		return con;
	}

	public int adminLogin(String u, String p) {
		int i = 0;
		try {
			
			  Class.forName("com.mysql.jdbc.Driver"); 
			  Connection con =
			  DriverManager.getConnection("jdbc:mysql://localhost:3306/management",
			  "root", "root");
			
			//Connection con = createConnection();
			PreparedStatement ps = con.prepareStatement("select * from login where uname = ? and upwd = ? ");
			ps.setString(1, u);
			ps.setString(2, p);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				i = 1;
			}
			// con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return i;
	}

	public int registerStudent(StudentBean std) {
		int i = 0;
		try {
			Connection con = createConnection();
			PreparedStatement ps = con.prepareStatement("insert into student values(?,?,?,?,?)");
			ps.setString(1, std.getSname());
			ps.setInt(2, std.getSrollno());
			ps.setString(3, std.getSaddress());
			ps.setString(4, std.getScourse());
			ps.setString(5, std.getSmobile());

			i = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return i;
	}

	public ArrayList<StudentBean> getAllStudent() {
		ArrayList<StudentBean> list = new ArrayList();
		Connection con = null;
		try {
			con = createConnection();
			PreparedStatement ps = con.prepareStatement("select * from student order by sname");
			StudentBean st;
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				st = new StudentBean(rs.getString("sname"), rs.getInt("srollno"), rs.getString("saddress"),
						rs.getString("scourse"), rs.getString("smobile"));
				list.add(st);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	public int deleteStudent(int roll) {
		int i = 0;
		try {
			Connection con = createConnection();
			PreparedStatement ps = con.prepareStatement("delete from student where srollno=?");
			ps.setInt(1, roll);
			i = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return i;
	}

	public StudentBean getStudentRecord(int roll) {
		StudentBean std = null;
		Connection con = null;
		try {
			con = createConnection();
			PreparedStatement ps = con.prepareStatement("select * from student where srollno=?");
			ps.setInt(1, roll);

			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				std = new StudentBean(rs.getString("sname"), rs.getInt("srollno"), rs.getString("saddress"),
						rs.getString("scourse"), rs.getString("smobile"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return std;
	}

	public int updateStudent(StudentBean sb) {
		int i = 0;
		try {
			Connection con = createConnection();
			PreparedStatement ps = con
					.prepareStatement("update student set sname=?, saddress=?, scourse=?, smobile=? where srollno=?");
			ps.setString(1, sb.getSname());
			ps.setString(2, sb.getSaddress());
			ps.setString(3, sb.getScourse());
			ps.setString(4, sb.getSmobile());
			ps.setInt(5, sb.getSrollno());
			i = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return i;
	}

	public int checkIdExists(int roll) {
		int i=0;
		try {
			Connection con = createConnection();
			PreparedStatement ps = con.prepareStatement("select * from student where srollno=?");
			ps.setInt(1, roll);
			ResultSet rs = ps.executeQuery();
			if(rs.next()) {
				i=1;
			}
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return i;
	}
}